package com.example.hello746;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class LikeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_like);
    }
}
